import yfinance as yf
print("yfinance", yf.__version__)
for s in ["OJFA","0769","VTI"]:
    try:
        d = yf.Ticker(s).dividends
        print(s, "->", type(d).__name__, (len(d) if d is not None else None))
    except Exception as e: print(s, "-> RAISES", type(e).__name__, str(e)[:60])
